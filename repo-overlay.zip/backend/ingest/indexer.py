from __future__ import annotations
import hashlib, time
from pathlib import Path
from typing import List, Dict, Any
from langchain_community.vectorstores import Chroma
from langchain.docstore.document import Document

from .manifest import Manifest
from .loaders import load_doc
from .chunking import splitter_for_ext

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1<<20), b""):
            h.update(chunk)
    return h.hexdigest()

def _with_metadata(docs: List[Document], path: Path) -> List[Document]:
    ext = path.suffix.lower().lstrip(".")
    for d in docs:
        d.metadata = {
            **(d.metadata or {}),
            "path": str(path),
            "filename": path.name,
            "ext": ext,
            "mtime": path.stat().st_mtime,
        }
    return docs

def sync_knowledge(base: str = "backend/knowledge", chroma_dir: str = "backend/.chroma", embeddings=None):
    base_path = Path(base)
    chroma_dir = Path(chroma_dir)
    chroma_dir.mkdir(parents=True, exist_ok=True)

    manifest = Manifest(chroma_dir / "manifest.json")
    vs = Chroma(collection_name="knowledge", persist_directory=str(chroma_dir), embedding_function=embeddings)

    # Collect files
    files = [p for p in base_path.rglob("*") if p.is_file() and not p.name.startswith(".")]
    current_keys = [str(p) for p in files]

    # Upsert/Update changed files
    for path in files:
        digest = sha256_file(path)
        entry = manifest.get(str(path))
        if entry and entry.get("sha256") == digest:
            continue  # unchanged

        # delete old chunks if present
        if entry and entry.get("doc_ids"):
            try:
                vs.delete(ids=entry["doc_ids"])
            except Exception:
                pass

        raw_docs = load_doc(path)
        docs = _with_metadata(raw_docs, path)
        splitter = splitter_for_ext(path.suffix)
        chunks = splitter.split_documents(docs)

        ids = vs.add_documents(chunks)  # returns IDs
        manifest.set(str(path), {
            "sha256": digest,
            "mtime": path.stat().st_mtime,
            "doc_ids": ids,
            "indexed_at": time.time(),
        })

    # Remove deleted files
    for stale in manifest.keys_not_in(current_keys):
        entry = manifest.get(stale)
        if entry and entry.get("doc_ids"):
            try:
                vs.delete(ids=entry["doc_ids"])
            except Exception:
                pass
        manifest.delete(stale)

    manifest.save()
    vs.persist()
    return True
