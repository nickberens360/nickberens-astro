from __future__ import annotations
from pathlib import Path
from typing import List
from langchain.docstore.document import Document

# LangChain community loaders
from langchain_community.document_loaders import (
    PyPDFLoader,
    BSHTMLLoader,
    UnstructuredMarkdownLoader,
    UnstructuredFileLoader,
    Docx2txtLoader,
    CSVLoader,
    JSONLoader,
)
from bs4 import BeautifulSoup

def _clean_html(text: str) -> str:
    # basic cleanup; you can extend
    return " ".join(text.split())

def load_doc(path: Path) -> List[Document]:
    path = Path(path)
    ext = path.suffix.lower()
    if ext == ".pdf":
        docs = PyPDFLoader(str(path)).load()
        # page numbers already included as metadata by PyPDFLoader
        return docs
    if ext in (".md", ".markdown"):
        return UnstructuredMarkdownLoader(str(path)).load()
    if ext in (".html", ".htm"):
        docs = BSHTMLLoader(str(path)).load()
        for d in docs:
            d.page_content = _clean_html(d.page_content)
        return docs
    if ext in (".docx",):
        return Docx2txtLoader(str(path)).load()
    if ext in (".txt",):
        return UnstructuredFileLoader(str(path)).load()
    if ext in (".csv",):
        return CSVLoader(str(path)).load()
    if ext in (".json",):
        return JSONLoader(str(path)).load()
    # Fallback
    return UnstructuredFileLoader(str(path)).load()
